//
// Created by Huawei on 12/09/2022.
//

#ifndef EXAMPLE4_1_OTHER_H
#define EXAMPLE4_1_OTHER_H

#include <stdio.h>
#include "stdlib.h"

#define size 10

void printArray(int pInt[100], int *pNEl);

void insertValue(int pInt[100], int *pNEl);

void writeValue(int pInt[100], int *pNEl);

void removeValue(int pInt[100], int *pInt1);

int present(int el, int *pInt, int *pNel);



#endif //EXAMPLE4_1_OTHER_H
