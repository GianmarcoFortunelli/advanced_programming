//
// Created by Huawei on 09/09/2022.
//

#ifndef INC_5_4_OTHER_H
#define INC_5_4_OTHER_H

#include <stdio.h>
#include "stdlib.h"

int *iniArray(int *size);

void insertArray(int *pInt, int size);

void cleanArray(int *pInt, int s);

void printArray(int *pInt, int s);


#endif //INC_5_4_OTHER_H
