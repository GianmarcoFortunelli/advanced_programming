//
// Created by Huawei on 05/09/2022.
//

#ifndef EX3_1_OTHER_H
#define EX3_1_OTHER_H

extern void recursiveFibonacci(int num);
extern void iterativeFibonacci(int num);

#endif //EX3_1_OTHER_H
